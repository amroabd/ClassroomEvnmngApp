package com.is.classroomevnmngapp.ui.admin.config_sensor;

import android.app.Application;

import com.is.classroomevnmngapp.view_model.HelperProcessesViewModel;

public class ConfigSensorsAdminViewModel extends HelperProcessesViewModel {


    public ConfigSensorsAdminViewModel(Application application) {
        super(application);

    }


    public void sendConfigSensor(String classroom,String sensor){

    }


}