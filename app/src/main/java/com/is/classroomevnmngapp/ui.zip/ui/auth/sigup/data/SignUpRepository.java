package com.is.classroomevnmngapp.ui.auth.sigup.data;

public class SignUpRepository {
}
