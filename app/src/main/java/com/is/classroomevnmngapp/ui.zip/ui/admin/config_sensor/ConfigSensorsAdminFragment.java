package com.is.classroomevnmngapp.ui.admin.config_sensor;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.is.classroomevnmngapp.databinding.FragmentAdminConfigSensorsBinding;
import com.is.classroomevnmngapp.utils.spinner.ListSpinner;
import com.is.classroomevnmngapp.utils.spinner.ListSpinnerAdapter;

import java.util.ArrayList;
import java.util.List;

public class ConfigSensorsAdminFragment extends Fragment {
    private static final String TAG = "ConfigSensorsAdminFragm";
    private ConfigSensorsAdminViewModel viewModel;
    FragmentAdminConfigSensorsBinding sensorsBinding;
      private List<ListSpinner>listSpinners;
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(ConfigSensorsAdminViewModel.class);
        sensorsBinding=FragmentAdminConfigSensorsBinding.inflate(inflater,container,false);

        return sensorsBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sensorsBinding.startCheckButton.setOnClickListener(view1 -> {
            sendConfigSensor();
        });
        //--
        loadSpinnerClassroom();
        loadSpinnerSensor();
    }

    private void loadSpinnerClassroom(){
        listSpinners=new ArrayList<>(0);
        viewModel.getSpinnerList("1", listSpinner -> listSpinners=listSpinner);
        ListSpinnerAdapter spinnerAdapter=new ListSpinnerAdapter(requireContext(),listSpinners);
        sensorsBinding.classroomSpinner.setAdapter(spinnerAdapter);
    }
    private void loadSpinnerSensor(){
        listSpinners=new ArrayList<>(0);
        viewModel.getSpinnerList("2", listSpinner -> listSpinners=listSpinner);
        ListSpinnerAdapter spinnerAdapter=new ListSpinnerAdapter(requireContext(),listSpinners);
        sensorsBinding.sensorSpinner.setAdapter(spinnerAdapter);
    }


    private void sendConfigSensor(){
       String sensorId= String.valueOf((ListSpinner)sensorsBinding.sensorSpinner.getAdapter().getItem(sensorsBinding.sensorSpinner.getListSelection()));
        String classId= String.valueOf((ListSpinner)sensorsBinding.classroomSpinner.getAdapter().getItem(sensorsBinding.classroomSpinner.getListSelection()));
        //-------------
        viewModel.sendConfigSensor(classId,sensorId);
    }


























}