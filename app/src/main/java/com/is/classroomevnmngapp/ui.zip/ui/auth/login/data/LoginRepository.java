package com.is.classroomevnmngapp.ui.auth.login.data;

public class LoginRepository {
}
